from flask import Flask, request, jsonify
from flask_cors import CORS
import os
from supabase import create_client
import sys

# Enable import from current dir
sys.path.append(os.path.dirname(__file__))

# --- IMPORT YOUR BMI LOGIC ---
from 2_1BMI_calc import get_body_composition_summary

# --- Initialize Flask App ---
app = Flask(__name__)
CORS(app)

# --- Supabase Setup ---
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

@app.route("/")
def home():
    return "✅ Vita backend is running"

@app.route("/api/analyze", methods=["POST"])
def analyze():
    try:
        user_id = request.json.get("user_id")
        if not user_id:
            return jsonify({"error": "Missing user_id"}), 400

        summary = get_body_composition_summary(user_id)
        return jsonify({"success": True, "data": summary})

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=10000)